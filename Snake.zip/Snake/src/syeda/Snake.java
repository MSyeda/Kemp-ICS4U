package syeda;
import java.awt.Color;
import java.awt.Graphics;

/**
 * Superclass for a generic moving object: Snake. This class takes care 
 * of the x and y locations (located at the center of the object), the speed
 * of x and y and the right, left, top and bottom sides of the screen. Then 
 * collisions with the edge of the screen are checked, and the
 * x and y speeds are reversed if necessary. <br>
 * <br>
 * 
 * The class implements a thread that updates the objects' position every 10 ms
 * (by default). At each step, the x and y locations are updated based on the 
 * x and y speeds. <br>
 * <br>
 * 
 * @version 11/01/2017
 * 
 * @author Maryam Syeda
 *
 */
public abstract class Snake implements Runnable{
	/**
	 * The x location of the object
	 */
	private double x;
	/**
	 * The y location of the object
	 */
	private double y;
	/**
	 * The x speed of the object
	 */
	private double xSpeed;
	/**
	 * The y speed of the object
	 */
	private double ySpeed;
	/**
	 * The right edge
	 */
	private int right;
	/**
	 * The left edge
	 */
	private int left;
	/**
	 * The top edge
	 */
	private int top;
	/**
	 * The bottom edge
	 */
	private int bottom;
	/**
	 * Length of pause between position updates. 
	 * This is the duration that the object will pause for.
	 */
	private int pauseDuration;
	/**
	 * Set moving to false to stop the thread
	 */
	private boolean moving;
	/**
	 * Object color
	 */
	protected Color color;
	/**
	 * 
	 * @param x
	 * 		Starting x location
	 * @param y
	 * 		Starting y location
	 * @param right
	 * 		Right side for bouncing
	 * @param left
	 * 		Left side for bouncing
	 * @param top
	 * 		Top side for bouncing
	 * @param bottom
	 * 		Bottom side for bouncing
	 */
	public Snake (double x, double y, int right, int left, int top, int bottom){
		this.pauseDuration = 40;
		this.xSpeed = 0;
		this.ySpeed = 0;
		this.x = x;
		this.y = y;
		this.right = right;
		this.left = left;
		this.top = top;
		this.bottom = bottom;
		startThread();
	}
	
	/**
	 * This method starts the thread
	 */
	private void startThread() {
		moving = true;
		Thread t = new Thread(this);
		t.start();
	}
	
	/**
	 * This method ends the thread by terminating the infinite loop in the main run()
	 */
	public void stopThread(){
		moving = false;
	}
	
	/**
	 * Animates the snake for one step
	 */
	abstract public void animateSnakeOneStep();
	
	/**
	 * Returns the current position of x
	 * 
	 * @return
	 * 		Gets the location of x
	 */
	public double getX(){
		return x;
	}
	
	/**
	 * Returns the current position of y
	 * 
	 * @return
	 * 		Gets the location of y
	 */
	public double getY(){
		return y;
	}
	
	/**
	 * Sets the speed of the snake (x)
	 * 
	 * @param xSpeed
	 * 		Returns the speed of x
	 */
	public void setXSpeed (double xSpeed){
		this.xSpeed = xSpeed;
	}
	
	/**
	 * Sets the speed of the snake (y)
	 * 
	 * @param ySpeed
	 * 		Returns the speed of y
	 */
	public void setYSpeed (double ySpeed){
		this.ySpeed = ySpeed;
	}
	
	/**
	 * Sets the location of x
	 * 
	 * @param x
	 * 		Returns the new location of x
	 */
	public void setX(int x){
		this.x = x;
	}
	
	/**
	 * Sets the location of y
	 * 
	 * @param y
	 * 		Returns the new location of y
	 */
	public void setY(int y){
		this.y = y;
	}

	/**
	 * This method updates the x and y locations in
	 * an infinite loop.
	 */
	public void run(){
		while(moving){
			animateSnakeOneStep();
			x += xSpeed;
			y += ySpeed;
			try{
				Thread.sleep(pauseDuration);
			} catch (InterruptedException e){
				
			}
		}
	}
	/**
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		

	}



}
