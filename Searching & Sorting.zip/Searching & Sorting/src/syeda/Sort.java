/**
 * 
 */
package syeda;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author Maryam Syeda
 *
 */
public class Sort {

	private static int[] elem; // Merge Sort
    private static int[] tempMergArr; // Merge Sort
    private static int length; // Merge Sort
    
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number of elements: ");	// Number of elements in the array
		int n = scn.nextInt(); 
		int[] elements = new int[n];

		System.out.println("Enter " + n + " integers: "); 		// Collection prompt
		for (int i = 0; i < n; i++){
			elements[i] = scn.nextInt();
		}
		System.out.println("Selection sort: ");
		selectionSort(elements);

		System.out.println("Insertion sort: ");
		insertionSort(elements);

		System.out.println("Bubble sort: ");
		bubbleSort(elements);

		System.out.println("Merge sort: ");
		mergeSort(elements);

		System.out.println("Quick sort: ");
		quickSortMain(elements);

	}

	/**
	 * This method carries out selection sort on the array: elements.
	 * It will sort the array in ascending order.
	 * 
	 * @param elements
	 * 			array of integers to be sorted
	 * @return
	 */
	public static int[] selectionSort(int[] elements){
		for (int i = 0; i < elements.length - 1; i++)
		{
			int index = i;
			for (int j = i + 1; j < elements.length; j++)
				if (elements[j] < elements[index]) 
					index = j;

			int smallerNumber = elements[index];  
			elements[index] = elements[i];
			elements[i] = smallerNumber;
		}
		return elements;
	}

	/**
	 * This method carries out insertion sort on the array: elements.
	 * It will sort the array in ascending order.
	 * 
	 * @param elements
	 * @return
	 */
	public static int[] insertionSort(int[] elements){
		int temp;
		for (int i = 1; i < elements.length; i++) {
			for(int j = i ; j > 0 ; j--){
				if(elements[j] < elements[j-1]){
					temp = elements[j];
					elements[j] = elements[j-1];
					elements[j-1] = temp;
				}
			}
		}
		return elements;
	}

	/**
	 * This method carries out bubble sort on the array: elements.
	 * It will sort the array in ascending order.
	 * 
	 * @param elements
	 * 			array of integers to be sorted
	 */
	public static void bubbleSort(int[] elements){
		int n = elements.length;
		int k;
		for (int m = n; m >= 0; m--) {
			for (int i = 0; i < n - 1; i++) {
				k = i + 1;
				if (elements[i] > elements[k]) {
					swapBubble(i, k, elements);
				}
			}
			printBubble(elements);
		}
	}

	/**
	 * This is a helper method to swap the numbers (creating temp)
	 * 
	 * @param i
	 * @param j
	 * @param elements
	 */
	private static void swapBubble(int i, int j, int[] elements) {

		int temp;
		temp = elements[i];
		elements[i] = elements[j];
		elements[j] = temp;
	}

	/**
	 * This is a helper method to print all the numbers being sorted
	 * 
	 * @param elements
	 */
	private static void printBubble(int[] elements) {

		for (int i = 0; i < elements.length; i++) {
			System.out.print(elements[i] + ", ");
		}
		System.out.println("\n");
	}

	/**
	 * This method carries out merge sort on the array: elements.
	 * It will sort the array in ascending order.
	 * 
	 * @param elements
	 * 			array of integers to be sorted
	 */
	public static void mergeSort(int[] elements){
		sort(elements);
        for(int i:elements){
            System.out.print(i);
            System.out.print(" ");
        }
    }
    
	/**
	 * This is a helper method for merge sort.
	 * It sorts and calls doMergeSortRecursion
	 * 
	 * @param elements
	 * 			array of integers
	 */
    public static void sort(int elements[]) {
        elem = elements;
        length = elements.length;
        tempMergArr = new int[length];
        doMergeSortRecursion(0, length - 1);
    }
 
    /**
     * This is a helper method for merge sort. 
     * It sorts the left side, right side, then merges. 
     * Then it calls mergeParts.
     * 
     * @param lowerIndex
     * 			lower index
     * @param higherIndex
     * 			higher index
     */
    private static void doMergeSortRecursion(int lowerIndex, int higherIndex) {
         
        if (lowerIndex < higherIndex) {
            int middle = lowerIndex + (higherIndex - lowerIndex) / 2;
            doMergeSortRecursion(lowerIndex, middle); // Sorts left side of the array
            doMergeSortRecursion(middle + 1, higherIndex); // Sort right side of the array
            mergeParts(lowerIndex, middle, higherIndex);	// Merge both sides of the array
        }
    }
 
    /**
     * This is a helper method that merges the everything together.
     * 
     * @param lowerIndex
     * 			lower index
     * @param middle
     * 			middle
     * @param higherIndex
     * 			higher index
     */
    private static void mergeParts(int lowerIndex, int middle, int higherIndex) {
 
        for (int i = lowerIndex; i <= higherIndex; i++) {
            tempMergArr[i] = elem[i];
        }
        int i = lowerIndex;
        int j = middle + 1;
        int k = lowerIndex;
        while (i <= middle && j <= higherIndex) {
            if (tempMergArr[i] <= tempMergArr[j]) {
            	elem[k] = tempMergArr[i];
                i++;
            } else {
            	elem[k] = tempMergArr[j];
                j++;
            }
            k++;
        }
        while (i <= middle) {
        	elem[k] = tempMergArr[i];
            k++;
            i++;
        }
    }

	/**
	 * This method carries out quick sort on the array: elements.
	 * It will sort the array in ascending order.
	 * 
	 * @param elements
	 * 			array of integers to be sorted
	 */
	public static void quickSortMain (int[] elements){
		int low = 0;
		int high = elements.length - 1;
		quickSort(elements, low, high);
		System.out.println(Arrays.toString(elements));
	}
 
	/**
	 * This method picks the pivot 
	 * @param arr
	 * @param low
	 * @param high
	 */
	public static void quickSort(int[] elements, int low, int high) {
		if (elements == null || elements.length == 0){
			return;
		}
		if (low >= high){
			return;
		}
		
		int middle = low + (high - low) / 2; // Selecting the pivot
		int pivot = elements[middle];
		
		int i = low, j = high; // Select left < pivot and right > pivot
		while (i <= j) {
			while (elements[i] < pivot) {
				i++;
			}
			while (elements[j] > pivot) {
				j--;
			}
			if (i <= j) {
				int temp = elements[i];
				elements[i] = elements[j];
				elements[j] = temp;
				i++;
				j--;
			}
		}
		if (low < j){ // Sort two parts using recursion
			quickSort(elements, low, j);
		}
		if (high > i){
			quickSort(elements, i, high);
		}
	}
}

