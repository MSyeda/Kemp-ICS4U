/**
 * 
 */
package syeda;

import java.util.Arrays;
import java.util.Scanner;

/**
 * @author Maryam Syeda
 *
 */
public class Search {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.println("Binary Search (1) or Linear Search (2)");
		int search = scn.nextInt();
		if(search == 1){ // Binary Search Type Options
			System.out.println("Integer (1) or Double (2) or String (3)");
			int type = scn.nextInt();
			if(type == 1){			// Binary Integer Search
				binaryIntSearch();
			}
			else if(type == 2){	// Binary Double Search
				binaryDoubleSearch();
			}
			else if(type == 3){	// Binary String Search
				binaryStringSearch();
			}
			else{							// Invalid option --> back to main
				main(args);
			}
		}
		else if(search == 2){ //Linear Search Type Options
			System.out.println("Integer (1) or Double (2) or String (3)");
			int type = scn.nextInt();
			if(type == 1){			// Linear Integer Search
				linearIntSearch();
			}
			else if(type == 2){	// Linear Double Search
				linearDoubleSearch();
			}
			else if(type == 3){	// Linear String Search
				linearStringSearch();
			}
			else{							// Invalid option --> back to main
				main(args);
			}
		}
		else{								// Invalid option --> back to main
			System.out.println("Please enter a valid number.");
			main(args);
		}
	}

	/**
	 * This method is a binary search for integers
	 * 
	 * @return
	 */
	public static int binaryIntSearch(){
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number of elements: ");	// Number of elements in the array
		int n = scn.nextInt(); 
		int[] binIntS = new int[n];

		System.out.println("Enter " + n + " integers: "); 		// Collection prompt
		for (int i = 0; i < n; i++){
			binIntS[i] = scn.nextInt();
		}

		System.out.println("Please enter the element you wish to find: ");	// Collecting the target
		int target = scn.nextInt();

		int first  = 0;
		int last   = n - 1;
		int middle = (first + last)/2;

		while(first <= last){
			if (binIntS[middle] < target){
				first = middle + 1; 
			}
			else if ( binIntS[middle] == target){
				System.out.println(target + " found at location " + (middle + 1) + "."); // Found the location
				break;
			}
			else{
				last = middle - 1;
				middle = (first + last)/2;
			}
		}
		if ( first > last ){				// Target is not found in current list
			return -1;
		}
		return 0;
	}


	/**
	 * This method is a linear search for integers
	 * 
	 * @return
	 */
	public static int linearIntSearch(){
		Scanner scn = new Scanner(System.in);
		int i;
		System.out.println("Enter the number of elements: ");		// Number of elements in the array
	    int n = scn.nextInt(); 
	    int[] linIntS = new int[n];
	 
	    System.out.println("Enter " + n + " integers: ");			// Collection prompts
	    for ( i = 0; i < n; i++){
	      linIntS[i] = scn.nextInt();
	    }
	 
	    System.out.println("Enter value to find");					// Collecting the target
	    int target = scn.nextInt();
	    for ( i = 0; i < n; i++) {
	      if (linIntS[i] == target){     								// Target is found
	         System.out.println(target + " found at location " + (i + 1) + ".");
	          break;
	      }
	   }
	   if (i == n){  						// Target does not exist in current list
	      return -1;
	   }
	   return 0;
	}
	
	/**
	 * This method is a binary search for doubles
	 * 
	 * @return
	 */
	public static double binaryDoubleSearch(){
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number of elements: ");	// Number of elements in the array
		int n = scn.nextInt(); 
		double[] binDoubS = new double[n];

		System.out.println("Enter " + n + " doubles: "); 		// Collection prompt
		for (int i = 0; i < n; i++){
			binDoubS[i] = scn.nextDouble();
		}

		System.out.println("Please enter the element you wish to find: ");	// Collecting the target
		double target = scn.nextInt();

		int first  = 0;
		int last   = n - 1;
		int middle = (first + last)/2;

		while(first <= last){
			if (binDoubS[middle] < target){
				first = middle + 1; 
			}
			else if ( binDoubS[middle] == target){
				System.out.println(target + " found at location " + (middle + 1) + "."); // Found the location
				break;
			}
			else{
				last = middle - 1;
				middle = (first + last)/2;
			}
		}
		if ( first > last ){				// Target is not found in current list
			return -1;
		}
		return 0;
	}

	/**
	 * This method is a linear search for doubles
	 * 
	 * @return
	 */
	public static double linearDoubleSearch(){
		Scanner scn = new Scanner(System.in);
		int i;
		System.out.println("Enter the number of elements: ");		// Number of elements in the array
	    int n = scn.nextInt(); 
	    double[] linDoubS = new double[n];
	 
	    System.out.println("Enter " + n + " doubles: ");			// Collection prompts
	    for ( i = 0; i < n; i++){
	      linDoubS[i] = scn.nextDouble();
	    }
	 
	    System.out.println("Enter value to find");					// Collecting the target
	    double target = scn.nextInt();
	    for ( i = 0; i < n; i++) {
	      if (linDoubS[i] == target){     								// Target is found
	         System.out.println(target + " found at location " + (i + 1) + ".");
	          break;
	      }
	   }
	   if (i == n){  						// Target does not exist in current list
	      return -1;
	   }
		return 0;
	}
	
	/**
	 * This method is a binary search for Strings
	 * 
	 * @return
	 */
	public static String binaryStringSearch(){
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number of elements: ");	// Number of elements in the array
		int n = scn.nextInt(); 
		String[] binStringS = new String[n];

		System.out.println("Enter " + n + " strings: "); 		// Collection prompt
		for (int i = 0; i < n; i++){
			binStringS[i] = scn.nextLine();
		}
		
		Arrays.sort(binStringS);
        Arrays.toString(binStringS);
        
        System.out.println("Enter string to find");					// Collecting the target
	    String target = scn.nextLine();
        int index = Arrays.binarySearch(binStringS, target);
        return null;
	}
	
	/**
	 * This method is a linear search for Strings
	 * 
	 * @return
	 */
	public static String linearStringSearch(){
		Scanner scn = new Scanner(System.in);
		System.out.println("Enter the number of elements: ");	// Number of elements in the array
		int n = scn.nextInt(); 
		String[] linStringS = new String[n];

		System.out.println("Enter " + n + " strings: "); 		// Collection prompt
		for (int i = 0; i < n; i++){
			linStringS[i] = scn.nextLine();
		}
	
        System.out.println("Enter string to find: ");					// Collecting the target
	    String target = scn.nextLine();
	    boolean test = false;
	    
	    for(int i=0;i<linStringS.length;i++){
            if(linStringS[i].equals(target)) {
                System.out.println(target +" found at location "+(i + 1));
                test = true;
                break;
            }
        }
        if(test=false) {
            System.out.println(target +" does not exist in current array.");
        }
		return null;
	}
}
